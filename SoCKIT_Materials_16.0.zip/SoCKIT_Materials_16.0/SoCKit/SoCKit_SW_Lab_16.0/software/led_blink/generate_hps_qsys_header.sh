#!/bin/sh
sopc-create-header-files \
"${SOCEDS_DEST_ROOT}/examples/hardware/cv_soc_devkit_ghrd_rev_a/soc_system.sopcinfo" \
--single hps_0.h \
--module hps_0
