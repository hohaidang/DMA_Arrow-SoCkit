#!/bin/sh -x

arm-linux-gnueabihf-gcc \
-g \
-O0 \
-Werror \
-Wall \
-I${SOCEDS_DEST_ROOT}/ip/altera/hps/altera_hps/hwlib/include  \
-I${SOCEDS_DEST_ROOT}/ip/altera/hps/altera_hps/hwlib/include/soc_cv_av	\
-D soc_cv_av \
-o led_blink \
main.c
